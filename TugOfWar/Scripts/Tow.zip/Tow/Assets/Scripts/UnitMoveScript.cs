﻿using UnityEngine;
using System.Collections;

[RequireComponent(typeof(NavMeshAgent))]
public class UnitMoveScript : MonoBehaviour
{
    public int team;
    public Transform destination;
    private NavMeshAgent myAgent;
    // Use this for initialization
    void Start ()
    {
        myAgent = GetComponent<NavMeshAgent>();
        myAgent.SetDestination(destination.position);
	}
	
	// Update is called once per frame
	void Update () {
	
	}

    public void move(Vector3 location)
    {
        myAgent.SetDestination(location);
    }
    public void resume()
    {
        myAgent.SetDestination(destination.position);
    }
}
