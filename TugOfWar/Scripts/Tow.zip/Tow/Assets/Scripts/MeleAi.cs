﻿using UnityEngine;
using System.Collections;

public class MeleAi : MonoBehaviour
{

    private int team;
    private UnitMoveScript mScript;
    private MinionScript myStats;
    public bool canAttack = true;
    public float attackCooldown;
    private Transform target;
    bool agro = false;
	// Use this for initialization
	void Start ()
    {
        team = gameObject.GetComponent<UnitMoveScript>().team;
        myStats = gameObject.GetComponent<MinionScript>();
        mScript = gameObject.GetComponent<UnitMoveScript>();
    }
	
	// Update is called once per frame
	void Update ()
    {
        if(agro == true)
        {
            if (target.gameObject.active == true)
            {
                attack(target.position);
            }
            else
            {
                agro = false;
                mScript.move(mScript.destination.position);
            }
        }
        

       
    }
    void OnTriggerStay(Collider col)
    {
        targetBadguy(col.gameObject);
    }
    void OnTriggerEnter(Collider col)
    {
        targetBadguy(col.gameObject);
    }
    void targetBadguy(GameObject badGuy)
    {
        UnitMoveScript enemy = badGuy.GetComponent<UnitMoveScript>();
        if (enemy != null && target != null)
        {
            if (enemy.team != team)
            {
                target = enemy.transform;
                agro = true;
            }
        }
    }
    void attack(Vector3 targetPos)
    {    
        mScript.move(targetPos);
    }

    void OnCollisionEnter(Collision col)
    {

       MinionScript enemy = col.gameObject.GetComponent<MinionScript>();
       swing(enemy);
    }

    void OnCollisionStay(Collision col)
    {
        MinionScript enemy = col.gameObject.GetComponent<MinionScript>();
        swing(enemy);
    }

    void swing(MinionScript enemy)
    {
        if (enemy != null && canAttack == true)
        {
            if (enemy.gameObject.GetComponent<UnitMoveScript>().team != team)
            {
                if (enemy.takeDamage(myStats.damage))
                {
                    target = null;
                    agro = false;
                    mScript.move(mScript.destination.position);
                }
                if(gameObject.active == true)
                {
                    StartCoroutine(coolDown(attackCooldown));
                }
                

            }
        }
    }

    IEnumerator coolDown(float cd)
    {
        canAttack = false;
        yield return new WaitForSeconds(cd);
        canAttack = true;
    }
}
