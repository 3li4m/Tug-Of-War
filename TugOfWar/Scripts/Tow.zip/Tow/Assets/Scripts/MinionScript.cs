﻿using UnityEngine;
using System.Collections;

public class MinionScript : MonoBehaviour {
    public int hp;
    public int damage;
    private MeleAi mAi;
	// Use this for initialization
	void Start ()
    {
        mAi = GetComponent<MeleAi>();
	}
	
	// Update is called once per frame
	void Update () {
	
	}
    public bool takeDamage(int damage)
    {
        hp -= damage;
        if (hp <= 0)
        {
            die();
            return true;
        }
        return false;
    }
    void die()
    {
        mAi.StopAllCoroutines();
        print("i died kek");
        gameObject.SetActive(false);
    }
}
