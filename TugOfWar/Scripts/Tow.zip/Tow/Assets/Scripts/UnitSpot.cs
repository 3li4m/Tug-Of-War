﻿using UnityEngine;
using System.Collections;

public class UnitSpot : MonoBehaviour 
{
	public bool isTaken;
}
